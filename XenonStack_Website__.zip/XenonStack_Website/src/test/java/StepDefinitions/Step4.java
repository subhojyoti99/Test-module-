package StepDefinitions;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Step4 {

    WebDriver driver= new ChromeDriver();
    JavascriptExecutor js = (JavascriptExecutor) driver;

    @Given("The user is on the xenonstack.com home again")
    public void user_is_on_home_again(){
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.xenonstack.com");
    }

    @When("the user clicks on the \"Blog\" link in the navigation menu")
    public void user_clicks_navigate_menu(){
        WebElement navigateMenu= driver.findElement(By.xpath("//*[@id=\"resources\"]/span"));
        navigateMenu.click();
        WebElement blogBtn= driver.findElement(By.xpath("//*[@id=\"myHeader\"]/div/div/div/div[2]/div/div[2]/div/div[1]/ul/li[1]/a/p"));
        blogBtn.click();
    }

    @Then("the user should be navigated to the Blog page")
    public void user_navigate_to_blog_page(){
        WebElement blogHeadLine= driver.findElement(By.xpath("/html/body/div[2]/section[1]/div/div/h1"));
        Assert.assertTrue("Blog head line is not displayed", blogHeadLine.isDisplayed());
        System.out.println("10th test case passed.");
    }

    @And("the user should see the list of blog posts and choose one")
    public void sees_blog_posts(){
        js.executeScript("window.scrollTo(0,50,document.body.scrollHeight)");
        WebElement blogCategories= driver.findElement(By.xpath("/html/body/div[2]/section[2]/div/div[2]/div/div[4]/div/a/div/h3"));
        Assert.assertTrue("Blog categories is not displayed", blogCategories.isDisplayed());
        blogCategories.click();
        System.out.println("11th test case passed.");
    }

    @And("the user should be able to view the blog details")
    public void clicks_view_blog_details(){
        js.executeScript("window.scrollTo(0,350,document.body.scrollHeight)");
        WebElement tracingPost = driver.findElement(By.xpath("//*[@id=\"Menu1\"]/div/div[5]/div/div/div/div/h3/a"));
        tracingPost.click();
        System.out.println("12th test case passed.");
        driver.close();
    }
}