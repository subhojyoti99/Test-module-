package StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.TimeUnit;

public class Step3 {

    WebDriver driver= new ChromeDriver();
    JavascriptExecutor js = (JavascriptExecutor) driver;

    @Given("The user is still on the xenonstack.com home page")
    public void user_is_on_home_page_again(){
        driver.manage().window().maximize();
        driver.get("https://www.xenonstack.com/");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @When("the user clicks on the \"Solutions\" link in the navigation menu")
    public void user_clicks_solution_link(){
//        Actions action = new Actions(driver);
//        WebElement Accelerators = driver.findElement(By.xpath("//*[@id=\"solutions\"]/span"));
//        action.moveToElement(Accelerators).perform();
//        WebElement solutionButton = driver.findElement(By.xpath("//*[@id=\"header-drop\"]/div/div[3]/div/div[3]/button/a"));
//        solutionButton.click();
    }

    @Then("the user hover on the Accelerators and click the button")
    public void hover(){
        Actions action = new Actions(driver);
        WebElement Accelerators = driver.findElement(By.xpath("//*[@id=\"solutions\"]/span"));
        action.moveToElement(Accelerators).perform();
        WebElement solutionButton = driver.findElement(By.xpath("/html/body/div[2]/div[1]/header/div/nav/div/ul[1]/li[3]/div[3]/div/div/div[3]/div/div[3]/button/a"));
        solutionButton.click();
        System.out.println("6th test case Passed.");
    }

    @And("the user should be navigated to the Solutions page")
    public void navigate_to_solution(){
        String solutionURL= "https://www.xenonstack.com/solutions/";
        String currentURL = driver.getCurrentUrl();
        if(solutionURL.equals(currentURL)){
            System.out.println("7th test case passed.");
        }
    }

    @And("the user should see the list of available solutions")
    public void sees_the_list(){
        js.executeScript("window.scrollTo(0,3500,document.body.scrollHeight)");
        WebElement headLineEnterprise = driver.findElement(By.xpath("/html/body/div[2]/section[4]/div/div/div[5]/div[1]/h2"));
        Assert.assertTrue("Headline Enterprise is not displayed", headLineEnterprise.isDisplayed());
        System.out.println("8th test case Passed.");
    }

    @And("the user should see the \"Contact Us\" section at the bottom of the page")
    public void sees_contact_us(){
        js.executeScript("window.scrollTo(0, 4700,document.body.scrollHeight)");
        WebElement contactForm = driver.findElement(By.xpath("//*[@id=\"section-eight\"]/div/div/div[1]/h3"));
        Assert.assertTrue("Contact us form is not displayed", contactForm.isDisplayed());
        System.out.println("9th test case Passed.");
        driver.close();
    }
}