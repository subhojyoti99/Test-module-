package StepDefinitions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import java.util.concurrent.TimeUnit;

public class Step5 {
    WebDriver driver;

    @Given("The User is now on xenonstack.com website home page")
    public void user_is_on_the_XenonStack_home_page() {
        // Initialize the driver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.xenonstack.com/");


    }


    @When("user click search button")
    public void user_click_search_button_and_search_anythings() {
        WebElement user_click_search_button = driver.findElement(By.xpath("//*[@id=\"search-menu\"]/img"));
        user_click_search_button.click();
    }

    @Then("search engine input box should open")
    public void search_engine_is_working_properly() {
        WebElement inputBox = driver.findElement(By.xpath("//*[@id=\"hs_cos_wrapper_search\"]/div/div/form/input"));
        Assert.assertTrue("Inout box is not displayed.", inputBox.isDisplayed());
        System.out.println("13th test case passed.");
    }

    @And("user should enter some topic to search")
    public void user_search_something() {
        driver.findElement(By.xpath("//*[@id=\"hs_cos_wrapper_search\"]/div/div/form/input")).sendKeys("full-stack development");
        driver.findElement(By.xpath("//*[@id=\"hs_cos_wrapper_search\"]/div/div/form/input")).sendKeys(Keys.ENTER);
        String strUrl1 = "https://www.xenonstack.com/hs-search-results?term=full-stack+development";
        String strUrl2 = driver.getCurrentUrl();
        if (strUrl1.equals(strUrl2)) {
            System.out.println("14th test case passed.");
        }
    }

    @And("user should get the content of the topic")
    public void user_should_get_the_content_of_the_topic() {
        WebElement userGetTheContent = driver.findElement(By.xpath("//*[@id=\"hsresults\"]/li[1]/a"));
        userGetTheContent.click();
        System.out.println("15th test case passed.");
    }

    @And("user searches some topic which is not present")
    public void user_search_something_which_is_not_present() {
        WebElement user_click_search_button = driver.findElement(By.xpath("/html/body/div[2]/div[1]/header/div/nav/div/ul[2]/li[2]/img"));
        user_click_search_button.click();
        driver.findElement(By.xpath("/html/body/div[2]/div[1]/header/div/div[2]/div/div[1]/div/div/div/div/div/form/input")).sendKeys("Subhojyoti");
        driver.findElement(By.xpath("/html/body/div[2]/div[1]/header/div/div[2]/div/div[1]/div/div/div/div/div/form/input")).sendKeys(Keys.ENTER);
        System.out.println("16th test case passed.");}

    @And("user should see no results found")
    public void user_see_no_results() {
        WebElement UserSeeNoResults = driver.findElement(By.xpath("//*[@id=\"hsresults\"]/div/p[1]"));
        System.out.println("17th test case passed.");
        driver.close();
    }
}