package StepDefinitions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Step2 {
    WebDriver driver = new ChromeDriver();

    @Given("The user is on the xenonstack.com home page again")
    public void user_is_on_home_page(){
        driver.manage().window().maximize();
        driver.get("https://www.xenonstack.com/");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @When("the home page is loaded")
    public void home_page_loaded(){
    }

    @Then("the user should see the XenonStack logo")
    public void see_the_logo(){
        WebElement xenonStackLogo = driver.findElement(By.xpath("//*[@id=\"xs-header\"]/div/nav/div/ul[1]/li[1]/a/img"));
        Assert.assertTrue("XenonStack logo is not displayed", xenonStackLogo.isDisplayed());
        System.out.println("2nd test case Passed.");
    }

    @And("user should see the navigation menu")
    public void see_the_navigation(){
        WebElement xenonStackNavigation = driver.findElement(By.xpath("//*[@id=\"xs-header\"]/div/nav"));
        Assert.assertTrue("Navigation menu is not displayed", xenonStackNavigation.isDisplayed());
        System.out.println("3rd test case Passed.");
    }

    @And("user should see the search bar")
    public void see_the_searchbar(){
        WebElement xenonStackSearchBar = driver.findElement(By.xpath("//*[@id=\"search-menu\"]/img"));
        xenonStackSearchBar.click();
        WebElement xenonStackSearchInput = driver.findElement(By.xpath("//*[@id=\"hs_cos_wrapper_search\"]/div/div/form/input"));
        Assert.assertTrue("Search bar is not displayed", xenonStackSearchInput.isDisplayed());
        System.out.println("4th test case Passed.");
    }

    @And("user should see the footer section")
    public void see_the_footer(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(265,document.body.scrollHeight)");
        WebElement xenonStackFooter = driver.findElement(By.xpath("/html/body/div[2]/div[3]/footer"));
        Assert.assertTrue("Footer is not displayed", xenonStackFooter.isDisplayed());
        System.out.println("5th test case Passed.");
        driver.close();
    }
}