package StepDefinitions;
import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import java.util.concurrent.TimeUnit;

public class Step1 {
    WebDriver driver;

    @Given("The user is on the xenonstack.com home page")
    public void user_is_on_the_XenonStack_home_page() {
        driver = new ChromeDriver();
        Actions action = new Actions(driver);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.xenonstack.com/");
    }

    @When("the user hover any five heading")
    public void user_hover_any_five_heading() {
        Actions action = new Actions(driver);
        WebElement services = driver.findElement(By.xpath("//*[@id=\"what-we-do\"]/span"));
        action.moveToElement(services).perform();
        WebElement UserShouldAbleToSeeContent = driver.findElement(By.xpath("//*[@id=\"header-drop\"]"));
        WebElement Accelerators = driver.findElement(By.xpath("//*[@id=\"solutions\"]/span"));
        action.moveToElement(Accelerators).perform();
        WebElement UserShouldAbleToSeeContent2 = driver.findElement(By.xpath("//*[@id=\"header-drop\"]"));
        WebElement Industries = driver.findElement(By.xpath("//*[@id=\"industries\"]/span"));
        action.moveToElement(Industries).perform();
        WebElement UserShouldAbleToSeeContent3 = driver.findElement(By.xpath("//*[@id=\"header-drop\"]"));
        WebElement Resources = driver.findElement(By.xpath("//*[@id=\"resources\"]/span"));
        action.moveToElement(Resources).perform();
        WebElement UserShouldAbleToSeeContent4 = driver.findElement(By.xpath("//*[@id=\"myHeader\"]/div/div/div"));
        WebElement Company = driver.findElement(By.xpath("//*[@id=\"company\"]/span"));
        action.moveToElement(Company).perform();
        WebElement UserShouldAbleToSeeContent5 = driver.findElement(By.xpath("//*[@id=\"header-drop\"]"));
    }

    @Then("the user should able to see navigation topics")
    public void user_should_able_to_see_five_heading_topics() {
        System.out.println("1st test case passed.");
        driver.close();
    }
}